package com.aldas.sebastian.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
