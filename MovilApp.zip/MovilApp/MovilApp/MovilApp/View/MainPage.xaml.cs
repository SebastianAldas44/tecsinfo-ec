﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using MovilApp.Model;
using Newtonsoft.Json;

namespace MovilApp
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public UsuarioList usuario;
        public MainPage()
        {
            InitializeComponent();

            listviewUsuario.IsVisible = false;
            GetJSON();
        }

        public async void GetJSON()
        {
            if (NetworkCheck.IsInternet())
            {
                var client = new System.Net.Http.HttpClient();
                var response = await client.GetAsync("https://tecsinfo-ec.com:9444/AuthenticationWS/login_user_db?username=admin&password=012b80343b93299e5464c1668e01609a");
                string usuarioJson = await response.Content.ReadAsStringAsync();
                this.usuario = new UsuarioList();
                if (usuarioJson != "")
                {
                    usuario = JsonConvert.DeserializeObject<UsuarioList>(usuarioJson);
                }
                listviewUsuario.ItemsSource = usuario.usuarios;
                listviewUsuario.IsVisible = true;
            }
        }
    }
}
