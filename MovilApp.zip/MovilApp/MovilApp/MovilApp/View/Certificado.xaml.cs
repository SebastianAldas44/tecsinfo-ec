﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using MovilApp.Model;
using Newtonsoft.Json;

namespace MovilApp.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Certificado : ContentPage
    {
        //private CertificadoController certificadoController;
        public CertificadoList certificados;
        public Certificado()
        {
            InitializeComponent();
            //certificadoController = new CertificadoController();
            GetJSON();
        }

        public async void GetJSON()
        {
            if (NetworkCheck.IsInternet())
            {
                var client = new System.Net.Http.HttpClient();
                var response = await client.GetAsync("https://tecsinfo-ec.com:9444/AuthenticationWS/get_user_certificate?username=admin&authCode=12345678");
                string certificadoJson = await response.Content.ReadAsStringAsync();
                this.certificados = new CertificadoList();
                if (certificadoJson != "")
                {
                    this.certificados = JsonConvert.DeserializeObject<CertificadoList>(certificadoJson);
                }
                listviewCertificado.ItemsSource = certificados.certificados;
            }
        }
    }
}