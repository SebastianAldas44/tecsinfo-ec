﻿using System;
using System.Collections.Generic;
using System.Text;
using MovilApp.Model;
using Newtonsoft.Json;

namespace MovilApp.Controller
{
    public class CertificadoController
    {
        public CertificadoList certificados;

        public CertificadoController()
        {
            GetJSON();
        }
        public async void GetJSON()
        {
            if (NetworkCheck.IsInternet())
            {
                var client = new System.Net.Http.HttpClient();
                var response = await client.GetAsync("https://tecsinfo-ec.com:9444/AuthenticationWS/get_user_certificate?username=admin&authCode=12345678");
                string certificadoJson = await response.Content.ReadAsStringAsync();
                this.certificados = new CertificadoList();
                if (certificadoJson != "")
                {
                    this.certificados = JsonConvert.DeserializeObject<CertificadoList>(certificadoJson);
                }
                //certificados.certificados;
            }
        }
    }
}
