﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using MovilApp.Model;
using Xamarin.Forms;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

namespace MovilApp.Controller
{
    public class UsuarioController
    {
        public Usuario usuario { get; set; }
        public ICommand SearchCommand { get; set; }

        public UsuarioController()
        {
            GetJSON();
        }

        public async void GetJSON()
        {
            if (NetworkCheck.IsInternet())
            {
                var client = new System.Net.Http.HttpClient();
                var response = await client.GetAsync("https://tecsinfo-ec.com:9444/AuthenticationWS/login_user_db?username=admin&password=012b80343b93299e5464c1668e01609a");
                string usuarioJson = await response.Content.ReadAsStringAsync();
                this.usuario = new Usuario();
                if (usuarioJson != "")
                {
                    usuario = JsonConvert.DeserializeObject<Usuario>(usuarioJson);
                }
            }
        }
    }
}
