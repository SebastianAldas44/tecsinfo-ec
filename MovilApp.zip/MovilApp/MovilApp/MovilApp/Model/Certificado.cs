﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovilApp.Model
{

    public class Certificado
    {
        public int id { get; set; }
        public Statuskey statusKey { get; set; }
        public Typekey typeKey { get; set; }
        public string name { get; set; }
        public string username { get; set; }
        public string ident { get; set; }
        public long date { get; set; }
        public string certificateName { get; set; }
        public string certificateCN { get; set; }
        public string certificatePassword { get; set; }
        public string certificateType { get; set; }
        public string certificateFile { get; set; }
        public string certificateFrom { get; set; }
        public string certificateTo { get; set; }
        public object company { get; set; }
    }

    public class Statuskey
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    public class Typekey
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    public class CertificadoList
    {
        public List<Certificado> certificados { get; set; }
    }

}
