﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovilApp.Model
{

    public class Usuario
    {
        public int userid { get; set; }
        public string name { get; set; }
        public string username { get; set; }
        public string email { get; set; }
        public string pushId { get; set; }
        public string status { get; set; }
        public string lastname { get; set; }
        public string role { get; set; }
        public string phone { get; set; }
        public string cel { get; set; }
        public string identifier { get; set; }
        public Listorderdetail[] listOrderDetails { get; set; }
        public object[] listLicenseAssignment { get; set; }
        public object[] listTempLicAssig { get; set; }
        public Emissionpoint emissionPoint { get; set; }
        public object[] listAuthFactorResponse { get; set; }
        public Listtypefactor2[] listTypeFactor2 { get; set; }
        public string[] permissions { get; set; }
        public string[] permissionsPlan { get; set; }
    }

    public class Emissionpoint
    {
        public int id { get; set; }
        public string code { get; set; }
        public string description { get; set; }
        public Establishment establishment { get; set; }
        public string status { get; set; }
    }

    public class Establishment
    {
        public int id { get; set; }
        public string code { get; set; }
        public string description { get; set; }
        public string address { get; set; }
        public string phone { get; set; }
        public string status { get; set; }
        public Company company { get; set; }
    }

    public class Company
    {
        public int id { get; set; }
        public int ambient { get; set; }
        public int typeEmission { get; set; }
        public string businessName { get; set; }
        public string tradeName { get; set; }
        public string ruc { get; set; }
        public string matrixAddress { get; set; }
        public string specialContributor { get; set; }
        public string boundAccounting { get; set; }
    }

    public class Listorderdetail
    {
        public int id { get; set; }
        public int quantity { get; set; }
        public float price { get; set; }
        public float discount { get; set; }
        public string status { get; set; }
        public int balance { get; set; }
        public long dateend { get; set; }
        public Idorder idorder { get; set; }
        public Idplan idplan { get; set; }
    }

    public class Idorder
    {
        public int id { get; set; }
        public long orderdate { get; set; }
        public Idcompany idcompany { get; set; }
        public object refstore { get; set; }
    }

    public class Idcompany
    {
        public int id { get; set; }
        public int ambient { get; set; }
        public int typeEmission { get; set; }
        public string businessName { get; set; }
        public string tradeName { get; set; }
        public string ruc { get; set; }
        public string matrixAddress { get; set; }
        public string specialContributor { get; set; }
        public string boundAccounting { get; set; }
    }

    public class Idplan
    {
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string period { get; set; }
        public string stock { get; set; }
        public int validity { get; set; }
        public int refprice { get; set; }
        public int refquantity { get; set; }
        public Permission[] permissions { get; set; }
    }

    public class Permission
    {
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
    }

    public class Listtypefactor2
    {
        public int id { get; set; }
        public string name { get; set; }
        public int level { get; set; }
        public Statusauthfactor statusAuthFactor { get; set; }
    }

    public class Statusauthfactor
    {
        public int id { get; set; }
        public object name { get; set; }
    }

    public class UsuarioList
    {
        public List<Usuario> usuarios { get; set; }
    }

}
