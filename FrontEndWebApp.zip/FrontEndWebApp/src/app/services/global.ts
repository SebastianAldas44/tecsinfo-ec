export var Global = {
	// Url del backend creado en spring
	url: 'http://localhost:8080/'
};