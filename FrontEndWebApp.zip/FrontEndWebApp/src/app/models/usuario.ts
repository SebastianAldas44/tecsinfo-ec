export class Usuario{
	constructor(
		public nombre: string,
		public nick: string,
		public clave: string
	){}
}